SAPI Integration Test
=====================

```
# run php-fpm
composer install
./vendor/bin/phpunit
```

these test cases checks php life cycles.